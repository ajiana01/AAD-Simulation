package com.dicoding.courseschedule.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

//TODO 1 : Define a local database table using the schema in app/schema/course.json -done
@Entity(tableName = "course")
data class Course(
    @field:PrimaryKey(autoGenerate = true)
    @field:ColumnInfo(name = "id")
    val id: Int = 0,
    @field:ColumnInfo(name = "courseName")
    val courseName: String,
    @field:ColumnInfo(name = "day")
    val day: Int,
    @field:ColumnInfo(name = "startTime")
    val startTime: String,
    @field:ColumnInfo(name = "endTime")
    val endTime: String,
    @field:ColumnInfo(name = "lecturer")
    val lecturer: String,
    @field:ColumnInfo(name = "note")
    val note: String
)
