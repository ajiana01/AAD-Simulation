package com.dicoding.courseschedule.ui.add

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.dicoding.courseschedule.R
import com.dicoding.courseschedule.ui.list.ListViewModelFactory
import com.dicoding.courseschedule.util.TimePickerFragment
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AddCourseActivity : AppCompatActivity(), TimePickerFragment.DialogTimeListener {
    private lateinit var viewModel: AddCourseViewModel
    private lateinit var edCourse: TextView
    private lateinit var edLecturer: TextView
    private lateinit var edNote: TextView
    private lateinit var spinner: Spinner
    private lateinit var startTime: TextView
    private lateinit var endTime: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_course)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.add_course)

        val factory = ListViewModelFactory.createFactory(this)
        viewModel = ViewModelProvider(this, factory)[AddCourseViewModel::class.java]
        initializeViews()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_add, menu)
        return super.onCreateOptionsMenu(menu)
    }

    private fun initializeViews() {
        edCourse = findViewById(R.id.add_ed_course)
        edLecturer = findViewById(R.id.add_ed_lecturer)
        edNote = findViewById(R.id.add_ed_note)
        spinner = findViewById(R.id.add_course_day)
        startTime = findViewById(R.id.add_tv_start_time)
        endTime = findViewById(R.id.add_tv_end_time)
    }

    @Suppress("DEPRECATION")
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_insert -> {
                handleInsertAction()
                true
            }
            android.R.id.home -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun handleInsertAction() {
        val course = edCourse.text.toString().trim()
        val lecturer = edLecturer.text.toString().trim()
        val note = edNote.text.toString().trim()
        val day = spinner.selectedItemPosition

        if (validateInput(course, lecturer, note)) {
            viewModel.insertCourse(course, day, startTime.text.toString(), endTime.text.toString(), lecturer, note)
            finish()
        } else {
            Toast.makeText(this, getString(R.string.empty_list_message), Toast.LENGTH_SHORT).show()
        }
    }

    private fun validateInput(vararg inputs: String): Boolean {
        return inputs.none { it.isEmpty() }
    }

    override fun onDialogTimeSet(tag: String?, hour: Int, minute: Int) {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, hour)
        calendar.set(Calendar.MINUTE, minute)
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        if (tag == "startTimePicker")
            findViewById<TextView>(R.id.add_tv_start_time).text = timeFormat.format(calendar.time)
        else if (tag == "endTimePicker")
            findViewById<TextView>(R.id.add_tv_end_time).text = timeFormat.format(calendar.time)
    }

    fun showTimePickerStartTime(view: View) {
        val dialogFragment = TimePickerFragment()
        dialogFragment.show(supportFragmentManager, "startTimePicker")
    }

    fun showTimePickerEndTime(view: View) {
        val dialogFragment = TimePickerFragment()
        dialogFragment.show(supportFragmentManager, "endTimePicker")
    }
}