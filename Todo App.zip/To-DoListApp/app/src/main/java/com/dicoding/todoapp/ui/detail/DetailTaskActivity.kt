package com.dicoding.todoapp.ui.detail

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.dicoding.todoapp.R
import com.dicoding.todoapp.data.Task
import com.dicoding.todoapp.ui.ViewModelFactory
import com.dicoding.todoapp.utils.DateConverter
import com.dicoding.todoapp.utils.TASK_ID

class DetailTaskActivity : AppCompatActivity() {
    private lateinit var viewModel: DetailTaskViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_task_detail)

        //TODO 11 : Show detail task and implement delete action -done
        val getId = intent.getIntExtra(TASK_ID, 0)
        val factory = ViewModelFactory.getInstance(this)
        viewModel = ViewModelProvider(this, factory)[DetailTaskViewModel::class.java]
        viewModel.setTaskId(getId)
        viewModel.task.observe(this, Observer(this::showDetails))
        deleteTask()
    }

    private fun showDetails(task: Task?) {
        val title: TextView = findViewById(R.id.detail_ed_title)
        val desc: TextView = findViewById(R.id.detail_ed_description)
        val date: TextView = findViewById(R.id.detail_ed_due_date)
        if (task != null) {
            title.text = task.title
            desc.text = task.description
            date.text = DateConverter.convertMillisToString(task.dueDateMillis)
        }
    }

    private fun deleteTask() {
       val deleteButton: Button = findViewById(R.id.btn_delete_task)
         deleteButton.setOnClickListener {
              viewModel.deleteTask()
              finish()
         }
    }
}