package com.dicoding.todoapp.data

import androidx.annotation.NonNull
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

//TODO 1 : Define a local database table using the schema in app/schema/tasks.json -done

@Entity(tableName = "tasks")
data class Task(
    @field:PrimaryKey(autoGenerate = true)
    @NonNull
    @field:ColumnInfo(name = "id")
    val id: Int = 0,
    @NonNull
    @field:ColumnInfo(name = "title")
    val title: String,
    @NonNull
    @field:ColumnInfo(name = "description")
    val description: String,
    @NonNull
    @field:ColumnInfo(name = "dueDate")
    val dueDateMillis: Long,
    @NonNull
    @field:ColumnInfo(name = "completed")
    val isCompleted: Boolean = false
)
